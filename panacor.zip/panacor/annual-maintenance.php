<?php require_once('header.php');?>
<title>Health Care | Panacor Technologies LLC</title>
<!-- Font Awesome -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
  rel="stylesheet"
/>

 <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div>
        </div>
        
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/services.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>OUR SERVICES</h2>
                </div>
            </div>
        </section>  
        
        <section class="trusted-company" id="mission" style="margin-top:40px;">
            <div class="container">
                <div class="row">
                    <div class="row">
                        <div class="col-2">
                            <!-- Tab navs -->
                            <div
                                class="nav flex-column nav-pills text-center"
                                id="v-pills-tab"
                                role="tablist"
                                aria-orientation="vertical"
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-healthcare-tab"
                                    href="healthcare.php"
                                    role="tab"
                                    >healthcare</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-hospitality-tab"
                                    href="#"
                                    role="tab"
                                    >hospitality</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-education-tab"
                                    href="#"
                                    role="tab"
                                    >education</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-government-tab"
                                    href="#"
                                    role="tab"
                                    >government</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-retail-tab"
                                    href="retail.php"
                                    role="tab"
                                    >retail</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-residential-tab"
                                    href="residential.php"
                                    role="tab"
                                    >residential</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-corporate-tab"
                                    href="#"
                                    role="tab"
                                    >corporate</a
                                >
                                <a
                                    class="nav-link active"
                                    id="v-pills-annual-maintenance-tab"
                                    href="annual-maintenance.php"
                                    role="tab"
                                    >Annual Maintenance</a
                                >
                            </div>
                            <!-- Tab navs -->
                        </div>

                        <div class="col-8" style="margin-left:65px">
                            <!-- Tab content -->
                            <div class="tab-content" id="v-pills-tabContent">
                                <div
                                    class="tab-pane fade show active"
                                    id="v-pills-annual-maintenance"
                                    role="tabpanel"
                                    aria-labelledby="v-pills-annual-maintenance-tab"
                                >
                                <section class="trusted-company" id="mission">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="trusted-company__right">
                                                    <div class="section-title text-left">
                                                        <div class="section-title__tagline-box">
                                                            <span class="section-title__tagline">MAINTENANCE CONTRACT</span>                                    
                                                        </div>                                
                                                    </div>
                                                    <p class="trusted-company__text-2">Panacor's technical team can be consulted to design and develop the best, most efficient and unbiased solutions for your needs - especially when you are looking to value engineer. Besides design and installation, we provide anumber of flexible options to keep your systems up and running all the time, regardless of scale or complexity. Panacor's team of qualified, experienced and competent engineers are committed to maximizing your systems' uptime and are available on call 24 x 7.</p>
                                                    <h6>YOU MAY CHOOSE ONE OF THE FOLLOWING MAINTENANCE OPTIONS:</h6>
                                                    <p class="trusted-company__text-2">Annual contracts hand us complete onus to maximize your system's efficiency. They allow us to get a complete snapshot of your systems, periodically assess each component and proactively handle issues such that you never experience downtime because we develop preventive maintenance schedules and regularly service all components, handling issues remotely if required.Incident contracts where you call upon us to resolve a particular issue and we guarantee performance for a certain period.</p>
                                                    <table id="customers">
                                                        <tr>
                                                            <th style="background-color:#db2f27;">You may also engage us for investigating, analyzing, assessing, and resolving:</th>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i>  Poor computer performance issues</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i> Computer freezes/crashes</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i> Password Resets</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i> Email/virus issues</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i> Network Access Issues</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i> Network Connectivity Issues</td>
                                                        </tr>
                                                        <tr>
                                                            <td><i class="fa fa-long-arrow-alt-right"></i> Third party software issues</td>
                                                        </tr>
                                                    </table>
                                                    <h6 style="margin-top:30px">CHOOSE US AS YOUR IT MAINTENANCE PARTNER IN DUBAI</h6>
                                                    <p class="trusted-company__text-2">Through the assistance of our IT services, your business can be rest assured about all your IT equipment. We are available 24/7 to resolve complaints that might be in cases critical to the business lifeline. Comprehensive contracts are entitled to replacement or repair of defective components Periodic IT assessment helps us provide a real snapshot of your IT resources Annual maintenance Dubai services are carried out by qualified, experienced, and competent engineers technicians. Remote support and monitoring ensure that your systems operate at an efficient performance level Use of right software tools and solutions enables us to help you enhance performance and serve your clients better Annual maintenance saves you on costly repairs or replacement later.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                </div>
                            </div>
                            <!-- Tab content -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- MDB -->

        <script>
            var coll = document.getElementsByClassName("collapsible");
            var i;

            for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active2");
                var content = this.nextElementSibling;
                if (content.style.maxHeight){
                content.style.maxHeight = null;
                } else {
                content.style.maxHeight = content.scrollHeight + "px";
                } 
            });
            }
        </script>  
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"
></script>
<?php require_once('footer.php');?>