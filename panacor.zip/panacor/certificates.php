<?php require_once('header.php');?>
<title>Certificate | Panacor Technologies LLC</title>
<style>
.blog-one__img {
    border-radius :15px;
}
</style>
  <!--Main Slider Start-->
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/certificates-header.webp);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>CERTIFICATES</h2>
                </div>
            </div>
             <!-- <div id="particles-js"></div>
             <img src="assets/images/backgrounds/bottom-shape.svg"> -->
        </section>    
        <!--Main Slider End-->

        
        <section class="blog-one"> 

            <div class="container">
                <div class="section-title text-left">
     
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__content">
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/certificates/2022_Reseller_Certificate.jpg">
                                        <div class="blog-one__img">
                                            <img src="assets/images/certificates/2022_Reseller_Certificate2.jpg" alt="">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__content">
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/certificates/EMEA_Crestron_Dealer_Certificate.jpg">
                                        <div class="blog-one__img">
                                            <img src="assets/images/certificates/EMEA_Crestron_Dealer_Certificate2.jpg" alt="">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__content">
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/certificates/ISO 9001- 2015_pages-to-jpg-0001.jpg">
                                        <div class="blog-one__img">
                                            <img src="assets/images/certificates/ISO 9001- 2015_pages-to-jpg-00012.jpg" alt="">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__content">
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/certificates/ISO 14001- 2015_pages-to-jpg-0001.jpg">
                                        <div class="blog-one__img">
                                            <img src="assets/images/certificates/ISO 14001- 2015_pages-to-jpg-00012.jpg" alt="">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__content">
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/certificates/ISO 45001- 2018_page-0001.jpg">
                                        <div class="blog-one__img">
                                            <img src="assets/images/certificates/ISO 45001- 2018_page-00012.jpg" alt="">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__content">
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/certificates/Cert_2020_Panacor Technologies LLC_page-0001.jpg">
                                        <div class="blog-one__img">
                                            <img src="assets/images/certificates/Cert_2020_Panacor Technologies LLC_page-00012.jpg" alt="">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>        
<script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.js"></script>
<script>
$('.preview_image').magnificPopup({
showCloseBtn: true,
closeBtnInside: true,
type:'image'});

</script>
</script>

        <!--Blog One End-->
        <!--Blog One End-->
<?php require_once('footer.php');?>