
        <!--Brand One Start-->
        <section class="brand-one" id="partner">
            <div class="container">
                <div class="section-title text-center">
                    <h2 class="section-title__title">We partner with the biggest names</h2>
                </div>
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100, "slidesPerView": 5, "centeredSlides": true, "roundLengths": true,"autoplay": { "delay": 5000 }, "breakpoints": {
                    "0": {
                        "spaceBetween": 30,
                        "slidesPerView": 2
                    },
                    "375": {
                        "spaceBetween": 30,
                        "slidesPerView": 2
                    },
                    "575": {
                        "spaceBetween": 30,
                        "slidesPerView": 3
                    },
                    "767": {
                        "spaceBetween": 50,
                        "slidesPerView": 4
                    },
                    "991": {
                        "spaceBetween": 50,
                        "slidesPerView": 5
                    },
                    "1199": {
                        "spaceBetween": 100,
                        "slidesPerView": 5
                    }
                }}'>

                    <div class="swiper-wrapper">
                        <div class="swiper-slide"><img src="assets/images/partners/1.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/2.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/3.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/4.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/5.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/6.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/7.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/9.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/10.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/11.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/21.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/22.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/24.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/25.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/26.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/27.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/28.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/29.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/30.jpg"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn1.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn2.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn3.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn4.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn5.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn6.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn7.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn8.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn9.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn10.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn11.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn12.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn13.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn14.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn15.png"></div>
                        <div class="swiper-slide"><img src="assets/images/partners/partn16.png"></div>
                    </div>
                </div>
            </div>
        </section>
        <!--Brand One End-->
        <!--<section class="cons_subscribe_area_two">-->
        <!--    <img src="assets/images/backgrounds/top-shape_grey.svg" class="top_divider">-->
        <!--    <div class="container">-->
        <!--        <div class="row">-->
        <!--            <div class="col-md-7">-->
        <!--                <h4>Subscribe for updates</h4>-->
        <!--                <p>Keep up to date with the latest news, announcements and resources</p>-->
        <!--            </div>-->
        <!--            <div class="col-md-5">-->
        <!--                <form action="#" class="cons_subscribe_form">-->
        <!--                    <input type="text" class="form-control" value="Enter your email">-->
        <!--                    <button type="submit" class="theme_btn hover_style1">Subscribe</button>-->
        <!--                </form>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--    <img src="assets/images/backgrounds/bottom-shape_blue.svg" class="bottom_divider">-->
        <!--</section>-->
        <!--Site Footer Start-->
        <footer class="site-footer">
            <div class="site-footer__middle">
                <div class="container">
                    <div class="row">

                        <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                            <div class="footer-widget__column footer-widget__links clearfix">
                                <h3 class="footer-widget__title">Products & Solutions</h3>
                                <ul class="footer-widget__links-list list-unstyled clearfix">
                                    <li><a href="audio-visual-system.php">Audio Visual System</a></li>
                                    <li><a href="security-system.php">Security Systems</a></li>
                                    <li><a href="it-solution.php">IT Solutions</a></li>
                                    <li><a href="telecommunication.php">Telecommunications</a></li>
                                    <li><a href="home-automation-system.php">Home Automation Systems</a></li>
                                    <li><a href="digital-signage.php">Digital Signage</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                            <div class="footer-widget__column footer-widget__links clearfix">
                                <h3 class="footer-widget__title">Services</h3>
                                <ul class="footer-widget__links-list list-unstyled clearfix">
                                    <li><a href="#">Hospitality</a></li>
                                    <li><a href="healthcare.php">Healthcare</a></li>
                                    <li><a href="#">Education</a></li>
                                    <li><a href="#">Government</a></li>
                                    <li><a href="retail.php">Retail</a></li>
                                    <li><a href="residential.php">Residential</a></li>
                                    <li><a href="#">Corporate</a></li>
                                    <li><a href="annual-maintenance.php">Annual Maintenance</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                            <div class="footer-widget__column footer-widget__links clearfix">
                                <h3 class="footer-widget__title">About us</h3>
                                <ul class="footer-widget__links-list list-unstyled clearfix">
                                    <li><a href="about.php#profile">Profile</a></li>
                                    <li><a href="about.php#mission">Mission Vision &amp; Values</a></li>
                                    <li><a href="about.php#culture">Company Culture</a></li>
                                    <li><a href="about.php#team">The Team</a></li>
                                    <li><a href="#">Certificates</a></li>
                                    <li><a href="about.php#partner">Partners</a></li>
                                    <li><a href="news.php">News updates</a></li>
                                    <li><a href="about.php#business">Beyond Business</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                            <div class="footer-widget__column footer-widget__links clearfix">
                                <h3 class="footer-widget__title">Quick Links</h3>
                                <ul class="footer-widget__links-list list-unstyled clearfix">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About us</a></li>
                                    <li><a href="product-solution.php">Products & Solutions</a></li>
                                    <li><a href="clients.php">Clients</a></li>
                                    <li><a href="photo-gallery.php">Media Gallery</a></li>
                                    <li><a href="career.php">Careers</a></li>
                                    <li><a href="global-presence.php">Our Global Presence</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                            <div class="footer-widget__column footer-widget__contact clearfix">
                                <h3 class="footer-widget__title">Connect</h3>
                                <ul class="footer-widget__contact-list list-unstyled clearfix">
                                    <li>
                                        <div class="icon">
                                            <span class="icon-telephone"></span>
                                        </div>
                                        <div class="text">
                                            <p><a href="tel:980009850">+971 4 3687044</a></p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <span class="icon-email"></span>
                                        </div>
                                        <div class="text">
                                            <p><a href="mailto:info@panacor.com">info@panacor.com</a></p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <span class="icon-pin"></span>
                                        </div>
                                        <div class="text">
                                            <p>P.O. Box 282384</p>
                                            <p>509 Detroit House, Motor City, Dubai,</p>
                                            <p>United Arab Emirates</p>
                                        </div>
                                    </li>
                                </ul>
                                <div class="footer-widget__column footer-widget__social-box clearfix">
                                    <div class="site-footer__social">                                        
                                        <a href="https://www.facebook.com/PanacorTechnologiesLLC/"><i class="fab fa-facebook"></i></a>
                                        <a href="https://twitter.com/panacortech"><i class="fab fa-twitter"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="400ms">

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="footer_cert">
                                <li><img src="assets/images/cert/cert.png"></li>
                                <li><img src="assets/images/cert/avix.png"></li>
                                <li><img src="assets/images/cert/qrs.png"></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="site-footer__bottom">
                <div class="container">
                    <div class="row">
                     
                        <div class="col-xl-12">
                            <div class="site-footer__bottom-inner">
                                <p class="site-footer__bottom-text">© 2022 <a href="#">Panacor Technologies.</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--Site Footer End-->


    </div><!-- /.page-wrapper -->


    <div class="mobile-nav__wrapper">
        <div class="mobile-nav__overlay mobile-nav__toggler"></div>
        <!-- /.mobile-nav__overlay -->
        <div class="mobile-nav__content">
            <span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

            <div class="logo-box">
                <a href="index.html" aria-label="logo image"><img src="Panacor%20logo.png" width="155" alt="" /></a>
            </div>
            <!-- /.logo-box -->
            <div class="mobile-nav__container"></div>
            <!-- /.mobile-nav__container -->
            



        </div>
        <!-- /.mobile-nav__content -->
    </div>
    <!-- /.mobile-nav__wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay search-toggler"></div>
        <!-- /.search-popup__overlay -->
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">Search servives....</label><!-- /.sr-only -->
                <input type="text" id="search" placeholder="Search Here..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <i class="icon-magnifying-glass"></i>
                </button>
            </form>
        </div>
        <!-- /.search-popup__content -->
    </div>
    <!-- /.search-popup -->

    <!--<a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>-->


    <script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
    <script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendors/jarallax/jarallax.min.js"></script>
    <script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
    <script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
    <script src="assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
    <script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
    <script src="assets/vendors/nouislider/nouislider.min.js"></script>
    <script src="assets/vendors/odometer/odometer.min.js"></script>
    <script src="assets/vendors/swiper/swiper.min.js"></script>
    <script src="assets/vendors/tiny-slider/tiny-slider.min.js"></script>
    <script src="assets/vendors/wnumb/wNumb.min.js"></script>
    <script src="assets/vendors/wow/wow.js"></script>
    <script src="assets/vendors/isotope/isotope.js"></script>
    <script src="assets/vendors/countdown/countdown.min.js"></script>
    <script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
    <script src="assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="assets/vendors/vegas/vegas.min.js"></script>
    <script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script src="assets/vendors/timepicker/timePicker.js"></script>
    <script src="assets/js/notech.js"></script>
    <script src="assets/js/custom.js"></script>

</body>

</html>