<?php require_once('header.php');?>
<title>News & Updates | Panacor Technologies LLC</title>
  <!--Main Slider Start-->
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/news.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>NEWS & UPDATES</h2>
                </div>
            </div>
             <div id="particles-js"></div>
             <!-- <img src="assets/images/backgrounds/bottom-shape.svg"> -->
        </section>    
        <!--Main Slider End-->

        
        <section class="blog-one"> 

            <div class="container">
                <div class="section-title text-left">
     
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/news/news_1.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">New Face of the Year by Logitech</a>
                                </h3>
                                <p>Panacor Technologies LLC was named Logitech's New Face of the Year at the Partner Summit 2022.</p>
                                <!--<div class="blog-one__bottom">-->
                                <!--    <a href="#">Read <i class="fa fa-long-arrow-alt-right"></i></a>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/news/news_2.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">"Organization's Culture" Award</a>
                                </h3>
                                <p>An organisations's culture is the bedrock of its internal and external interactions.Panacor awarded for having best organization's culture</p>
                                <!--<div class="blog-one__bottom">-->
                                <!--    <a href="#">Read <i class="fa fa-long-arrow-alt-right"></i></a>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/news/news_3.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Choosing an MSP? </a>
                                </h3>
                                <p>While choosing MSP,Think “partner”, not “supplier.This will help you to do the best decision.</p>
                                <!--<div class="blog-one__bottom">-->
                                <!--    <a href="#">Read <i class="fa fa-long-arrow-alt-right"></i></a>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
        </section>
        <!--Blog One End-->
        <!--Blog One End-->
<?php require_once('footer.php');?>