<?php require_once('header.php');?>
<style>
    .anchor {
    display: block;
    position: relative;
    top: -30vh;
    visibility: hidden;
}
</style>
<title>Careers | Panacor Technologies LLC</title>
 <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <!--Main Slider Start-->
        
        <section class="main-slider">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 5500
                }}'>
                <div class="swiper-wrapper">


                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image: url(assets/images/slider/career.webp); filter:opacity(60%);"></div>
                        <!-- /.image-layer -->
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="main-slider__content">
                                        <div class="slider_text">
                                            <h2><span style="color: #d6383b;">CAREERS</span></h2>
                                            <p>Panacor Technologies LLC offers numerous and excellent opportunities for talented candidates to improve their lives. We offer job opportunities as well as internship programs.</p>
                                        </div>
                                        <div class="main-slider__btn-video-box">
                                            <div class="main-slider__btn-box">
                                                <a href="#profile" class="thm-btn main-slider__btn">Learn more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- If we need navigation buttons -->
                <div class="swiper-pagination" id="main-slider-pagination"></div>

            </div>
        </section>
        
        
       
        <section class="delivering-it">
            <div class="container">
                <div class="delivering-it__top">
                 
                </div>                
            </div>
        </section>
        <section class="trusted-company" id="profile">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6" >
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/internship.webp" alt="">
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6" >
                        <div class="trusted-company__right">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline" >INTERNSHIP PROGRAM</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">Panacor's internship program aims at giving students an insight into the work ethics and practices and business philosophy along with the opportunity to learn about Products and Solutions.</p>
                            
                           
                            <p class="trusted-company__text-2">The new interns are warmly welcomed by our team of experts, who also enjoy teaching them new things, assisting them in developing new talents, and inspiring them to take on special projects that will be advantageous to both the business and themselves.</p>
                            
                            <p class="trusted-company__text-2">We want to lead the way in giving people the chance to improve their lives and we want to give people better lives.</p>
                            
                             <p class="trusted-company__text-2">For Our Internship Program,please send your request email to <a style="color : #ff5733" href="mailto:info@panacor.com">info@panacor.com</a></p>      
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
                <section class="trusted-company" id="profile">
            <div class="container">
                <div class="row">
                  
                    <div class="col-xl-6" >
                         <?php if (isset($_GET['invalid'])) { ?>
                            <div class="alert alert-danger" role="alert"><?php echo $_GET['invalid'];?></div>
                          <?php } 
                          if (isset($_GET['missing'])) { ?>
                            <div class="alert alert-warning" role="alert"><?php echo $_GET['missing'];?></div>
                          <?php }
                          if (isset($_GET['success'])) { ?>
                            <div class="alert alert-success" role="alert"><?php echo $_GET['success'];?></div>
                           <?php } ?>
                        <div class="trusted-company__right">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline" >APPLY NOW FOR JOBS</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">For the job opportunity, send your resume. Our team of specialists will analyze it and get in touch with you if you qualify.</p>
                            
                            <form  method="POST" action="resume-enquiry.php" enctype="multipart/form-data" onsubmit="return form_validation()">
                            <div class="row">    
                              <div class="trusted-company__text-2 col-md-6">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Full Name" >
                                <small style="color: red ; font-weight : bold" id="name_error"></small>
                              </div>  
                              
                                <div class="trusted-company__text-2 col-md-6">
                                <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter Contact No." >
                                <small style="color: red ; font-weight : bold" id="phone_error"></small>
                              </div>  
                            </div>  
                              
                              <div class="trusted-company__text-2">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email Address" >
                                <small style="color: red ; font-weight : bold" id="email_error"></small>
                              </div> 
                              
                              <div class="trusted-company__text-2">
                                <textarea class="form-control" id="cover_letter" name="cover_letter" rows="10" col="16" placeholder="Enter Cover Letter"></textarea>
                                <small style="color: #061451">* This field is optional *</small>
                              </div> 
                              
                               <div class="trusted-company__text-2">
                                <input type="file" class="form-control" id="resume" name="resume">
                                <small style="color: #061451">* Attach Your Resume : Only PDF and Word files are permitted, with a maximum upload size of 2MB. *</small>
                                <small style="color: red ; font-weight : bold" id="resume_error"></small>
                              </div> 
                              
                              <div class="trusted-company__text-2">
                                <input style="background-color:#ff5733 ; color:#FFFFFF" type="submit" class="btn"  id="send" name="send" value="SUBMIT">
                              </div> 
                              
                             
                              
                           
                            </form>
                         </div>
                    </div>
                    
                      <div class="col-xl-6" >
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInRight" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/job.webp" alt="">
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>        
<script>
    function form_validation()
  {
    var name = $('#name').val();  
    var phone = $('#phone').val();  
    var email = $('#email').val();   
    var resume = $('#resume').val(); 
    var fileExtension = ['doc', 'docx', 'pdf'];
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    
    if (name.length < 1) 
    {
      document.getElementById("name_error").innerHTML = "Please Enter Full Name";
      window.location.hash = '#name';
      return false;
    }
    else
    {
      document.getElementById("name_error").innerHTML = "";  
    }
    
    if (phone.length < 1) 
    {
      document.getElementById("phone_error").innerHTML = "Please Enter Phone Number";
      window.location.hash = '#phone';
      return false;
    }
    else
    {
      document.getElementById("phone_error").innerHTML = "";  
    }
    
    if (email.length < 1) 
          {
           document.getElementById("email_error").innerHTML = "Please Enter Email";
           window.location.hash = '#email';
           return false;
          }

          else if(email.length > 0)
          {
             if(!emailReg.test(email))
             {
              document.getElementById("email_error").innerHTML = "Please Enter Valid Email!";
              window.location.hash = '#email';
              return false;
             }

             else
             {
              document.getElementById("email_error").innerHTML = ""; 
             }  
     
          }
    
    
    if (resume.length < 1) 
          {
           document.getElementById("resume_error").innerHTML = "Please Select File";
           window.location.hash = '#resume';
           return false;
          }
          else if(resume.length > 0)
          {
          	
          		if ($.inArray($('#resume').val().split('.').pop().toLowerCase(), imagefileExtension) == -1) 
               {
                 document.getElementById("resume_error").innerHTML = "Only PDF/DOC/DOCX allowed";
                 window.location.hash = '#resume';
                 return false;
               }
               else
               {
                 document.getElementById("resume_error").innerHTML = "";

               }	
               	
          
          }
  }
  
</script>        
<?php require_once('footer.php');?>