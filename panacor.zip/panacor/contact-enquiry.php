<?php
if(isset($_POST['contact']))
{

    if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['project']) || empty($_POST['message']))
    {
        header("location:contact.php?missing=".urlencode('Fields are missing!Please fill them'));
        exit();
    }
    else
    {
      $name=$_POST['name'];
      $email=$_POST['email'];
      $project=$_POST['project'];
      $message=$_POST['message']; 
      
      $to = "info@panacor.com";
      $subject = "Contact Enquiry | Panacor Technologies LLC";
      $headers = "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
      $headers .= "From: ".$email."";
      $content='';
      include('contact-email-template.php');
      
      if(mail($to,$subject,$content,$headers))
      {
        header("location:contact.php?success=".urlencode('Thank you for your inquiry! We will contact you shortly'));
            exit();  
      }
      else
      {
          header("location:contact.php?invalid=".urlencode('Error Occured! Please Try Again'));
            exit();
      }
    }
    
}

?>