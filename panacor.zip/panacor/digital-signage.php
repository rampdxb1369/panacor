<?php require_once('header.php');?>
<style>
html, body {
    max-width: 100%;
    overflow-x: hidden;
}
</style>

<title>Products & Solutions | Panacor Technologies LLC</title>
        <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/product&solution.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>PRODUCTS & SOLUTIONS</h2>
                </div>
            </div>
        </section>  

        <section class="trusted-company" id="mission" style="margin-top:40px;">
            <div class="container">
                <div class="row">
                    <div class="row">
                        <div class="col-2">
                            <!-- Tab navs -->
                            <div
                                class="nav flex-column nav-pills text-center"
                                id="v-pills-tab"
                                role="tablist"
                                aria-orientation="vertical"
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-audio-visual-tab"
                                    href="audio-visual-system.php"
                                    role="tab"
                                    >Audio Visual System</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-security-system-tab"
                                    href="security-system.php"
                                    role="tab"
                                    >security system</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-it-solutions-tab"
                                    href="it-solution.php"
                                    role="tab"
                                    >it solutions</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-telecommunication-tab"
                                    href="telecommunication.php"
                                    role="tab"
                                    >telecommun-<br>ication</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-home-automation-system-tab"
                                    href="home-automation-system.php"
                                    role="tab"
                                    >home automation system</a
                                >
                                <a
                                    class="nav-link active"
                                    id="v-pills-digital-signage-tab"
                                    href="digital-signage.php"
                                    role="tab"
                                    >digital signage</a
                                >
                            </div>
                            <!-- Tab navs -->
                        </div>

                        <div class="col-8" style="margin-left:65px">
                            <!-- Tab content -->
                            <div class="tab-content" id="v-pills-tabContent">
                                <div
                                    class="tab-pane fade show active"
                                    id="v-pills-digital-signage"
                                    role="tabpanel"
                                    aria-labelledby="v-pills-digital-signage-tab"
                                >
                                <section class="trusted-company" id="mission">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="trusted-company__right">
                                                    <div class="section-title text-left">
                                                        <div class="section-title__tagline-box">
                                                            <span class="section-title__tagline">DIGITAL SIGNAGE</span>                                    
                                                        </div>                                
                                                    </div>
                                                    <p class="trusted-company__text-2">Customized Digital Signage Solutions for every business: Creative Digital Signages, LED Video Walls, LED Video Displays, Kiosks and more.At Panacor, We can help you handle every aspect of any digital signage requirement.</p>
                                                    <table id="customers">
                                                    <tr>
                                                        <th style="background-color:#db2f27;">TYPES OF SYSTEMS</th>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Digital menu boards</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Informative video walls</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Interactive screens</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Outdoor / Indoor LED displays</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> All-in-one screens</td>
                                                    </tr>
                                                </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                </div>
                            </div>
                            <!-- Tab content -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <script>
            var coll = document.getElementsByClassName("collapsible");
            var i;

            for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active2");
                var content = this.nextElementSibling;
                if (content.style.maxHeight){
                content.style.maxHeight = null;
                } else {
                content.style.maxHeight = content.scrollHeight + "px";
                }
            });
            }
        </script> 
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"
></script>

<?php require_once('footer.php');?>