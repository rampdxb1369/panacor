<?php require_once('header.php');?>
<style>
    @media (max-width: 991px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}
@media (max-width: 768px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 768px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 767px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 665px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 767px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 665px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 665px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 575px) {

    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}

@media (max-width: 480px) {
    .vid{
        height: 400px;
        pointer-events: none;
        background-color: #0072bb;
    }
}
</style>
<title> System Integration company in Dubai, UAE, IT solution providers in Dubai, System Integrators in UAE | Panacor.com </title>
        <!--Main Slider Start-->
        <section class="main-slider">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 3500
                }}'>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <video class="vid" style="pointer-events: none;" autoplay="true" preload="auto" controls="false" muted loop playsinline>
                            <source src="assets/images/slider/slds/panacor-sld.mp4" type="video/mp4">
                        </video>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="main-slider__content">
                                        <div class="slider_text">
                                            <h2><span>WE</span>  PROVIDE</h2>
                                            <p>Complete turnkey solutions from Consulting, Design and Engineering to Installation and Maintenance.</p>
                                        </div>
                                        <div class="main-slider__btn-video-box">
                                            <div class="main-slider__btn-box">
                                                <a href="about.php" class="thm-btn main-slider__btn">Discover more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image: url(assets/images/slider/slds/sld1.jpg); height:800px;"></div>
                        <!-- /.image-layer -->
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="main-slider__content">
                                        <div class="slider_text">
                                            <h2><span>Experts</span> in System Integration</h2>
                                            <p>Excellent team of professionals who have extensive experience in their fields.</p>
                                        </div>
                                        <div class="main-slider__btn-video-box">
                                            <div class="main-slider__btn-box">
                                                <a href="product-solution.php" class="thm-btn main-slider__btn">Discover more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image: url(assets/images/slider/slds/sld2.jpg); height:800px;"></div>
                        <!-- /.image-layer -->
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="main-slider__content">
                                        <div class="slider_text">
                                            <h2><span>IT</span> Solutions</h2>
                                            <p>Panacor Technologies LLC helps enterprises to assess their current IT Infrastructure and evaluates whether an upgrade is required.</p>
                                        </div>
                                        <div class="main-slider__btn-video-box">
                                            <div class="main-slider__btn-box">
                                                <a href="it-solution.php" class="thm-btn main-slider__btn">Discover more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image: url(assets/images/slider/slds/sld3.jpg); height:800px;"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="main-slider__content">
                                        <div class="slider_text">
                                            <h2><span>Technical</span> Expertise and Capability</h2>
                                            <p>With solid experience in the retail hospitality, entertainment, healthcare, financial services</p>
                                        </div>
                                        <div class="main-slider__btn-video-box">
                                            <div class="main-slider__btn-box">
                                                <a href="product-solution.php" class="thm-btn main-slider__btn">Discover more</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- If we need navigation buttons -->
                <div class="swiper-pagination" id="main-slider-pagination"></div>

            </div>
        </section>
        <!--Main Slider End-->

        <!--Get Solutions Start-->
        <section class="get-solutions">
            <div id="particles-js"></div>
            <div class="container">
                <div class="get-solutions__inner">
                    <p class="get-solutions__text">Innovate - Integrate - Inspire</p>
                </div>
            </div>
            <svg version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 451.5 424.5" style="enable-background:new 0 0 451.5 424.5;" xml:space="preserve" width="451.5" height="424.5">
                <style type="text/css">
                    .st0 {
                        stroke: #ffffff;
                        stroke-miterlimit: 10;
                    }
                </style>
                <!-- <polygon id="XMLID_4_" class="st0 svg-elem-1" points="84,171.2 437.2,15.5 14.2,409 76.2,272 283.5,109.7 "></polygon> -->
            </svg>
        </section>
        <!--Get Solutions End-->
        <section class="tech-services">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="tech-services__left">
                            <div class="tech-services__img-box wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                                <div class="tech-services__img">
                                    <img src="assets/images/slider/sld4.webp" alt="">
                                </div>
                                <div class="tech-services__img-content">
                                    <p class="tech-services__img-text">Providing Complete<br> Turnkey ICT<br> Solutions</p>
                                    <div class="tech-services__learn-more">
                                        <a href="about.php">Learn more <i class="fa fa-long-arrow-alt-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="tech-services__right">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline">Who we are</span>
                                </div>
                                <h2 class="section-title__title">Panacor Technologies LLC</h2>
                            </div>
                            <p class="tech-services__text">Panacor is a System Integration company with solid experience in the retail, hospitality, entertainment, healthcare, financial services, and transportation, education and government sectors across the Middle East.We provide complete turnkey solutions from Consulting, Design and Engineering to Installation and Maintenance.</p>
                            <p class="tech-services__text">Whether it is financial readiness for taking on large projects, the technical expertise to tailor-make innovative in-house solutions or the commitment needed to surpass every standard of service the market has seen, we are focused on being at the top. </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!--Feature One Start-->

        <!--Services One End-->

        <!--Business From Start-->
        <section class="business-from">
            <div class="business-from-bg-box">
                <div class="business-from-bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%" style="background-image: url(assets/images/slider/sld5.webp);"></div>
            </div>
            <div class="container">
                <div class="business-from__inner text-center">
                    <p class="business-from__sub-title">Expert in System Integration</p>
                    <h2 class="business-from__title">Excellent team of professionals who have extensive experience in their fields.</h2>
                    <div class="business-from__btn-box">
                        <a href="contact.php" class="business-from__btn thm-btn">Contact us now <img src="assets/icons/logo_arrow.svg"></a>
                    </div>
                </div>
            </div>
        </section>
        <!--Business From End-->


        <!--Project One Start-->
        <section class="project-one">
            <div class="project-one__inner">
                <div class="container">
                    <div class="section-title text-left">
                        <h2 class="section-title__title">Product & Solutions</h2>
                        <p>Panacor is a specialized System Integration company providing complete turnkey ICT solutions including
                            Security, Storage solutions, Audio-Visual, Digital signage and IT solutions. </p>
                    </div>
                    <div class="row serv_slider owl-carousel wow fadeInUp" data-wow-delay="200ms">
                        <div class="project-one__single">
                            <div class="project-one__img">
                                <img src="assets/images/services/s6.webp" alt="">
                                <a href="#">
                                    <img src="assets/icons/serv/digital.svg" alt="">
                                </a>
                            </div>
                            <div class="project-one__content">
                                <h3 class="project-one__title"><a href="audio-visual-system.php">Audio Visual Systems</a></h3>
                                <ul>
                                    <li><i class="fa fa-location-arrow"></i> Professional Audio</li>
                                    <li><i class="fa fa-location-arrow"></i> Professional Video</li>
                                    <li><i class="fa fa-location-arrow"></i> Public Address System</li>
                                </ul>
                            </div>
                        </div>
                        <div class="project-one__single project-one__single-two">
                            <div class="project-one__img">
                                <img src="assets/images/services/s5.webp" alt="">
                                <a href="#">
                                    <img src="assets/icons/serv/security.svg" alt="">
                                </a>
                            </div>
                            <div class="project-one__content">
                                <h3 class="project-one__title"><a href="security-system.php">Security Systems</a></h3>
                                <ul>
                                    <li><i class="fa fa-location-arrow"></i> CCTV and Surveillance</li>
                                    <li><i class="fa fa-location-arrow"></i> Access Control Systems</li>
                                    <li><i class="fa fa-location-arrow"></i> Parking Management</li>
                                </ul>
                            </div>
                        </div>

                        <div class="project-one__single project-one__single-three">
                            <div class="project-one__img">
                                <img src="assets/images/services/s1.webp" alt="">
                                <a href="#">
                                    <img src="assets/icons/serv/tele.svg" alt="">
                                </a>
                            </div>
                            <div class="project-one__content">
                                <h3 class="project-one__title"><a href="it-solution.php">IT Solutions</a></h3>
                                <ul>
                                    <li><i class="fa fa-location-arrow"></i> Server Load Balancing - Load Balancer ADC</li>
                                    <li><i class="fa fa-location-arrow"></i> Link Load Balancer - Link Balancer</li>
                                    <li><i class="fa fa-location-arrow"></i> Access Control - SSL VPN & Remote Acces </li>
                                </ul>
                            </div>
                        </div>
                        <div class="project-one__single project-one__single-three">
                            <div class="project-one__img">
                                <img src="assets/images/services/s2.webp" alt="">
                                <a href="#">
                                    <img src="assets/icons/serv/cloud.svg" alt="">
                                </a>
                            </div>
                            <div class="project-one__content">
                                <h3 class="project-one__title"><a href="telecommunication.php">Telecommunications</a></h3>
                               <ul>
                                    <li><i class="fa fa-location-arrow"></i> Analog/Digital PABX</li>
                                    <li><i class="fa fa-location-arrow"></i> IP Telephony</li>
                                    <li><i class="fa fa-location-arrow"></i> Wireless Communications</li>
                                </ul>
                            </div>
                        </div>
                        <div class="project-one__single project-one__single-three">
                            <div class="project-one__img">
                                <img src="assets/images/services/s3.webp" alt="">
                                <a href="#">
                                    <img src="assets/icons/serv/it.svg" alt="">
                                </a>
                            </div>
                            <div class="project-one__content">
                                <h3 class="project-one__title"><a href="home-automation-system.php">Home Automation Systems</a></h3>
                               <ul>
                                    <li><i class="fa fa-location-arrow"></i> Digital Signage</li>
                                    <li><i class="fa fa-location-arrow"></i> Large Format Display Screens</li>
                                    <li><i class="fa fa-location-arrow"></i> Professional Lighting (indoor / outdoor)</li>
                                </ul>
                            </div>
                        </div>
                        <div class="project-one__single project-one__single-three">
                            <div class="project-one__img">
                                <img src="assets/images/services/s4.webp" alt="">
                                <a href="#">
                                    <img src="assets/icons/serv/doc.svg" alt="">
                                </a>
                            </div>
                            <div class="project-one__content">
                                <h3 class="project-one__title"><a href="digital-signage.php">Digital Signage</a></h3>
                                <ul>
                                    <li><i class="fa fa-location-arrow"></i> Digital menu boards</li>
                                    <li><i class="fa fa-location-arrow"></i> Informative video walls</li>
                                    <li><i class="fa fa-location-arrow"></i> Interactive screens </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    <div class="col-md-12 text-center center_btn">
                        <a href="product-solution.php" class="thm-btn">Browse All <img src="assets/icons/logo_arrow.svg"></a>
                    </div>
                </div>
                </div>
            </div>
        </section>
        <!--Project One End-->

        <section class="process">
            <div class="section-padding bg-img bg-fixed section-padding" data-background="img/banner2.jpg" data-overlay-dark="6">
                <div class="container">                    
                    <div class="row">
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/icon/arrow1.png" class="tobotm arr" alt=""> <img src="assets/images/icon/wc1.png">
                                <h6>Smart Cities</h6>
                                <p>New Smart Street Light technology has been designed to represent the culmination of several sophisticated technologies in a single "pole" unit.</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/icon/arrow1.png" alt="" class="arr"> <img src="assets/images/icon/wc2.png">
                                <h6>SMART HOME SYSTEMS</h6>
                                <p>Home monitoring systems to assure that kids got home just fine, light sockets that can be switched on and off by an iPhone, thermostats</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/icon/arrow1.png" alt="" class="tobotm arr"> <img src="assets/images/icon/wc3.png">
                                <h6>IOT BUILDS</h6>
                                <p>The Internet of Things (IoT) is forging the digital economic era. IoT exists in a massive, sophisticated ecosystem that requires joint investment</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/icon/w34.png">
                                <h6>Maintenance Contracts</h6>
                                <p>Focus on your Core Business while our Experts Manage your Complex AV / Security Telecom and IT Environment.collaboration</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="blog-one"> 
             <img src="assets/images/backgrounds/bottom-shape_grey.svg" class="top_divider">
            <div class="container">
                <div class="section-title text-left">
                    <div class="section-title__tagline-box">
                        <span class="section-title__tagline">Resources</span>
                    </div>
                    <h2 class="section-title__title">Latest news & insights</h2>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/news/news_1.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Panacor Technologies LLC awarded as the New Face of the Year by Logitech in Partner Summit 2022</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a href="#">Read More<i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/news/news_2.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">An organisations's culture is the bedrock of its internal and external interactions.</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a href="#">Read More<i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/news/news_3.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Choosing an MSP? Think “partner”, not “supplier</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a href="#">Read More<i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center center_btn">
                        <a href="#" class="thm-btn">View all resources <img src="assets/icons/logo_arrow.svg"></a>
                    </div>
                </div>
            </div>
        </section>

        <!--Blog One End-->

 <?php require_once('footer.php');?>