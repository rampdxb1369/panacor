<?php require_once('header.php');?>
 <title> Contact Us |System Integration company in Dubai, UAE, IT solution providers in Dubai, System Integrators in UAE | Panacor.com </title>
 <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <!--Main Slider Start-->
        
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/contact-us.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>CONTACT US</h2>
                </div>
            </div>
             <!-- <div id="particles-js"></div>
             <img src="assets/images/backgrounds/bottom-shape.svg"> -->
        </section>    
        
         <section class="trusted-company">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12" style="text-align:center">
                        <br>
                     <div class="section-title__tagline-box">
                                    <span class="section-title__tagline" >GET IN TOUCH</span>                                    
                                </div> 
                     <br>
                     <p>Whether you need a quote to design a system from scratch for a new project or retro-fit a new aspect in an existing infrastructure or simply value-engineer the best possible solutions in a given budget, Panacor promises the quickest turnaround times on responding to inquiries. Write to info@panacor.com or call</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="trusted-company">
            <div class="container">
                <div class="row">
                     <div class="col-xl-6" >
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/main-office.webp" alt="" style="margin-top:50px; border-radius:20px;">
                                <div class="trusted-company__solution">
                                    <p class="trusted-company__solution-content">P.O. Box 282384,509 Detroit House,Motor City,Dubai, United Arab Emirates.
                                       <br>
                                       Phone : +971 4 3687044
                                       <br>
                                       Fax : +971 4 4308708
                                       <br>
                                       Email : info@panacor.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="col-xl-6" >
                          <?php if (isset($_GET['invalid'])) { ?>
                            <div class="alert alert-danger" role="alert"><?php echo $_GET['invalid'];?></div>
                          <?php } 
                          if (isset($_GET['missing'])) { ?>
                            <div class="alert alert-warning" role="alert"><?php echo $_GET['missing'];?></div>
                          <?php }
                          if (isset($_GET['success'])) { ?>
                            <div class="alert alert-success" role="alert"><?php echo $_GET['success'];?></div>
                           <?php } ?>
                        <div class="trusted-company__right">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline" >CONTACT ENQUIRY</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">We are here to help you with any questions or problems.</p>
                            
                            <form method="POST" action="contact-enquiry.php" enctype="multipart/form-data">
                            <div class="row">    
                              <div class="trusted-company__text-2 col-md-6">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Full Name" required>
                              </div>  
                              
                              <div class="trusted-company__text-2 col-md-6">
                                 <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email Address" required>
                              </div>  
                            </div>
                            
                            <div class="trusted-company__text-2">
                                 <input type="text" class="form-control" id="project" name="project" placeholder="Your Project" required>
                              </div>  

                              <div class="trusted-company__text-2">
                                <textarea class="form-control" id="message" name="message" rows="8" col="13" placeholder="Enter Message" required></textarea>
                              </div> 
            
                              
                              <div class="trusted-company__text-2">
                                <input style="background-color:#ff5733 ; color:#FFFFFF" type="submit" class="btn"  id="contact" name="contact" value="SUBMIT">
                              </div> 
                              
                             
                              
                           
                            </form>
                         </div>
                    </div>
                </div>
            </div>
        </section>
         <section class="container" style="border-radius:30px">   
           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.6486640865314!2d55.22971101533386!3d25.045994543963758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f6e7150e5f453%3A0x720746916e7f30c9!2sPANACOR%20TECHNOLOGIES%20LLC!5e0!3m2!1sen!2sae!4v1669186347685!5m2!1sen!2sae" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </section>
      
       
<?php require_once('footer.php');?>