<?php require_once('header.php');?>
<title>Our Global Presence | Panacor Technologies LLC</title>
<style>
h5 {
    color :#001743;
    font-weight :bold;
}

@media only screen and (max-width: 767px)
{
  h5 {
    color :#001743;
    font-weight :bold;
    font-size :16px;
}   
}
</style>
  <!--Main Slider Start-->
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/global-presence.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>OUR GLOBAL PRESENCE</h2>
                </div>
            </div>
             <!-- <div id="particles-js"></div>
             <img src="assets/images/backgrounds/bottom-shape.svg"> -->
        </section>    
        <!--Main Slider End-->

      <!--Client One End-->  
       <section class="process">
            <div class="section-padding bg-img bg-fixed section-padding" data-background="img/banner2.jpg" data-overlay-dark="6">
                <div class="container">                    
                    <div class="row">
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/location.png">
                                <h6>ABU DHABI</h6>
                                <p>Panacor Technologies LLC,Zig zag Building ,FAB Properties,Behind Dana Hotel,Abu Dhabi, UAE.</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/location.png">
                                <h6>BAHRAIN</h6>
                                <p>First Choice Advertising & Promotions Co. Spc,Office # 42, Building # 96,Road # 333, Block 321,Gudaibiya,Kingdom of Bahrain</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/location.png">
                                <h6>DUBAI HQ</h6>
                                <p>Panacor Technologies LLC,Office 509, Detroit house, Motorcity, Dubai, UAE.</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/location.png">
                                <h6>INDIA</h6>
                                <p>Avient Technologies Pvt Limited,Ground Floor, A-64,Villa A Block, Green Valley,Sector 41-42,Faridabad, Haryana,India.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>      
           
        </section>
        
         <section class="process">
            <div class="section-padding bg-img bg-fixed section-padding" data-background="img/banner2.jpg" data-overlay-dark="6">
                <div class="container">                    
                    <div class="row">
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/location.png">
                                <h6>KSA</h6>
                                <p>Tech First Gulf Branch Company,Office No:5, Othman Bin Affan Road, Exit 7,Riyadh,Saudi Arabia.</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/location.png">
                                <h6>UNITED KINGDOM</h6>
                                <p>ABTS Consultancy Ltd,M4 7LT, 1st Every Street,Manchester,UK.</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/location.png">
                                <h6>UNITED STATES OF AMERICA</h6>
                                <p>Comm-Port Technologies,1 Corporate Drive,Cranbury,NJ 08512,USA.</p>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/location.png">
                                <h6>QATAR</h6>
                                <p>Tech First General Trading Zone 6, Building 203,Al Maha,Qatar.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>      
           
        </section>

    
        <!--Client One End-->

<?php require_once('footer.php');?>