<?php require_once('header.php');?>
<title>Clients | Panacor Technologies LLC</title>
<style>
h4 {
    color :#001743;
    font-weight :bold;
}

@media only screen and (max-width: 767px)
{
  h4 {
    color :#001743;
    font-weight :bold;
    font-size :16px;
}   
}
</style>
  <!--Main Slider Start-->
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/clients.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>OUR PRESTIGIOUS CLIENTS</h2>
                </div>
            </div>
             <!-- <div id="particles-js"></div>
             <img src="assets/images/backgrounds/bottom-shape.svg"> -->
        </section>    
        <!--Main Slider End-->

      <!--Client One End-->  
       <section class="process">
            <div class="section-padding bg-img bg-fixed section-padding" data-background="img/banner2.jpg" data-overlay-dark="6">
                <div class="container">                    
                    <div class="row">
                        <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/dnata.png">
                             <h5 style="color:#001743;">DNATA <BR> TRAVEL GROUP</h5>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/emaar.png">
                                <h5 style="color:#001743;">EMAAR <br> GROUP</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/emirates.png">
                                <h5 style="color:#001743;">EMIRATES <BR> HEADQUARTERS</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/etihad.png">
                                <h5 style="color:#001743;">ETIHAD LOUNGES<BR> ABU DHABI AIRPORT</h4>
                            </div>
                        </div>
                        
                         <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/dubai-world-center.png">
                             <h5 style="color:#001743;">DUBAI WORLD <BR> CENTRAL AIRPORT</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/world-security.png">
                                <h5 style="color:#001743;">DUBAI WORLD <br> SECURITY</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/awqaf.png">
                                <h5 style="color:#001743;">AWQAF <BR> HEADQUARTERS</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/dufry.png">
                                <h5 style="color:#001743;">SHARJAH DUTY FREE<BR> DURFY</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/index.png">
                             <h5 style="color:#001743;">INDEX BOUTIQUE <BR> MALL</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/sharjah-university.png">
                                <h5 style="color:#001743;">SHARJAH <br> UNIVERSITY</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/ajman-university.png">
                                <h5 style="color:#001743;">AJMAN <BR> UNIVERSITY</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/sofitel.png">
                                <h5 style="color:#001743;">SOFITEL<BR> PALMS</h4>
                            </div>
                        </div>
                        
                         <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/emirates-post.png">
                             <h5 style="color:#001743;">EMIRATES <BR> POST</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/etisalat.png">
                                <h5 style="color:#001743;">ETISALAT <br> INNOVATION CENTER</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/dubai-muncipility.png">
                                <h5 style="color:#001743;">DUBAI <BR> MUNICIPALITY</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/dubai-police.png">
                                <h5 style="color:#001743;">DUBAI<BR> POLICE</h4>
                            </div>
                        </div>
                        
                         <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/novo.png">
                             <h5 style="color:#001743;">NOVO <BR> CINEMAS</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/tdic.png">
                                <h5 style="color:#001743;">TDIC <br> GROUP</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/jumeirah.png">
                                <h5 style="color:#001743;">JUMEIRAH <BR> GROUP</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/al-habtoor.png">
                                <h5 style="color:#001743;">AL HABTOOR<BR> GROUP</h4>
                            </div>
                        </div>
                        
                         <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/address.png">
                             <h5 style="color:#001743;">THE ADDRESS <BR> DUBAI MALL</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/mubadala.png">
                                <h5 style="color:#001743;">TMIC <br>MUBADALA GROUP</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/alserkal.png">
                                <h5 style="color:#001743;">AL-SERKAL <BR> AVENUE</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/meydan.png">
                                <h5 style="color:#001743;">MEYDAN <BR> HOTELS</h4>
                            </div>
                        </div>
                        
                         <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/republica.png">
                             <h5 style="color:#001743;">ITALIAN <BR> EMBASSY</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/emirates-palace.png">
                                <h5 style="color:#001743;">EMIRATES PALACE<br> ABU DHABI</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/hilton.png">
                                <h5 style="color:#001743;">HILTON FAMILY HOTEL <BR> ABU DHABI</h4>
                            </div>
                        </div>
                        
                        <div class="col-md-3 padding">
                            <div class="item text-center"> <img src="assets/images/client/louvre.png">
                                <h5 style="color:#001743;">LOUVRE MUSEUM<BR> ABU DHABI</h4>
                            </div>
                        </div>
                        
                         <div class="col-md-3 padding">
                            <div class="item text-center"><img src="assets/images/client/indian-pavilian.png">
                             <h5 style="color:#001743;">INDIAN <BR> PAVILIAN</h4>
                            </div>
                        </div>
                        <div class="col-md-3 padding">
                            <div class="item text-center">  <img src="assets/images/client/supercare.png">
                                <h5 style="color:#001743;">SUPERCARE <br> PHARMACY</h4>
                            </div>
                        </div>
                   
                    </div>
                </div>
            </div>      
           
        </section>

    
        <!--Client One End-->

<?php require_once('footer.php');?>