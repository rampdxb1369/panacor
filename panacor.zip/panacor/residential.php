<?php require_once('header.php');?>
<title>Health Care | Panacor Technologies LLC</title>
<!-- Font Awesome -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
  rel="stylesheet"
/>

 <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div>
        </div>
        
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/services.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>OUR SERVICES</h2>
                </div>
            </div>
        </section>  
        
        <section class="trusted-company" id="mission" style="margin-top:40px;">
            <div class="container">
                <div class="row">
                    <div class="row">
                        <div class="col-2">
                            <!-- Tab navs -->
                            <div
                                class="nav flex-column nav-pills text-center"
                                id="v-pills-tab"
                                role="tablist"
                                aria-orientation="vertical"
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-healthcare-tab"
                                    href="healthcare.php"
                                    role="tab"
                                    >healthcare</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-hospitality-tab"
                                    href="#"
                                    role="tab"
                                    >hospitality</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-education-tab"
                                    href="#"
                                    role="tab"
                                    >education</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-government-tab"
                                    href="#"
                                    role="tab"
                                    >government</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-retail-tab"
                                    href="retail.php"
                                    role="tab"
                                    >retail</a
                                >
                                <a
                                    class="nav-link active"
                                    id="v-pills-residential-tab"
                                    href="residential.php"
                                    role="tab"
                                    >residential</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-corporate-tab"
                                    href="#"
                                    role="tab"
                                    >corporate</a
                                >
                                <a
                                    class="nav-link"
                                    id="v-pills-annual-maintenance-tab"
                                    href="annual-maintenance.php"
                                    role="tab"
                                    >Annual Maintenance</a
                                >
                            </div>
                            <!-- Tab navs -->
                        </div>

                        <div class="col-8" style="margin-left:65px">
                            <!-- Tab content -->
                                <div
                                    class="tab-pane fade show active"
                                    id="v-pills-residential"
                                    role="tabpanel"
                                    aria-labelledby="v-pills-residential-tab"
                                >
                                <section class="trusted-company" id="mission">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="trusted-company__right">
                                                    <div class="section-title text-left">
                                                        <div class="section-title__tagline-box">
                                                            <span class="section-title__tagline">RESIDENTIAL - HOME AUTOMATION SYSTEM</span>                                    
                                                        </div>                                
                                                    </div>
                                                    <p class="trusted-company__text-2">We are a technology and services company dedicated to bringing innovation to the retails. At Panacor, we specialize in providing best solutions,services and more.</p>
                                                    <table id="customers">
                                                    <tr>
                                                        <th style="background-color:#db2f27;">Types of Solutions</th>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Lighting Control System</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Home Security & CCTV</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Intercom</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Home – Theatre</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Multi-Room Audio</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> SMARTV & IPTV</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Voice Control - Amazon</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Alexa Google Home</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Climate & Comfort</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Smart Curtains</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Health & Hygiene</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Smart burglar alarm</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Smart Door Locks and access control</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Smart TV</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Smart Doorbells</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Gaming Hub</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Wired and Wireless Network</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Structured Cabling & Fiber Optic</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Gate Barriers and Parking</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Management Systems</td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-long-arrow-alt-right"></i> Universal Smart Touch panel & Remote Control</td>
                                                    </tr>
                                                </table>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                </div>
                            </div>
                            <!-- Tab content -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- MDB -->

        <script>
            var coll = document.getElementsByClassName("collapsible");
            var i;

            for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active2");
                var content = this.nextElementSibling;
                if (content.style.maxHeight){
                content.style.maxHeight = null;
                } else {
                content.style.maxHeight = content.scrollHeight + "px";
                } 
            });
            }
        </script>  
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"
></script>
<?php require_once('footer.php');?>