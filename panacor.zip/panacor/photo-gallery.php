<?php require_once('header.php');?>
<title>Photos Gallery | Panacor Technologies LLC</title>
<style>
.blog-one__img {
    border-radius :15px;
}
</style>
  <!--Main Slider Start-->
         <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/gallery.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>PHOTOS GALLERY</h2>
                </div>
            </div>
             <!-- <div id="particles-js"></div>
             <img src="assets/images/backgrounds/bottom-shape.svg"> -->
        </section>    
        <!--Main Slider End-->

        
        <section class="blog-one"> 

            <div class="container">
                <div class="section-title text-left">
     
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Emirates-Head-Quarters.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Emirates Headquarters</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Emirates-Head-Quarters.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/dg3fI0Vo-Emirates-Palace_1.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Emirates palace Abu Dhabi</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/dg3fI0Vo-Emirates-Palace_1.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/yas-family-hotel-abu-dhabi-nightshot-pool.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Hilton - Family Hotel Abu Dhabi</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/yas-family-hotel-abu-dhabi-nightshot-pool.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/1422936-233253384.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Fujairah Business Centre - Fujairah</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/1422936-233253384.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Te44tYo9-Louvre-Abu-Dhabi-1-2.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Louvre Museum Abu Dhabi</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Te44tYo9-Louvre-Abu-Dhabi-1-2.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/the-index-72_xl.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">The Index Tower - Dubai</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/the-index-72_xl.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/maxresdefault.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Sharjah International Airport - Duty Free</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/maxresdefault.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/a99c0bdc-5c82-4152-8e98-eb86e23845f7-h.jpeg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">New Balance @ Dubai Mall</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/a99c0bdc-5c82-4152-8e98-eb86e23845f7-h.jpeg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/3130985267687017118.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Emirates Headquarters Auditorium</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/3130985267687017118.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-5.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Installations at Events</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/blog-5.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Bahrain-City-Center-Mall.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Max - Bahrain City Center Mall</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Bahrain-City-Center-Mall.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-6.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">The Meydan Hotel</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/blog-6.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-8.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">CCC Showroom AbuDhabi</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/blog-8.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-9.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Index Mall</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/blog-9.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-10.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Retail Outlet Installations</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/blog-10.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/image.khaleejtimes.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Indian Pavillion Expo 2020</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/image.khaleejtimes.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-12.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Circular LED Video Wall</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a href="assets/images/gallery/blog-12.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Super Care - Dubai Mall LED Installation Retail.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Supercare Pharmacy - Dubai Mall</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Super Care - Dubai Mall LED Installation Retail.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Fedperry - Dubai Hills.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Fedperry - Dubai Hills</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Fedperry - Dubai Hills.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Deisel - Yas Mall - AbuDhabi.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Deisel - Yas Mall - AbuDhabi</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Deisel - Yas Mall - AbuDhabi.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Aura Living - The Dubai Mall.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Aura Living - The Dubai Mall</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Aura Living - The Dubai Mall.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/gym.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Prioritize well Gym - Sound</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/gym.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/ACO - Avenues Mall - Kuwait.jpeg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Aco - Avenues Mall Kuwait</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/ACO - Avenues Mall - Kuwait.jpeg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Led Screen Installation - Al Wahda Mall Abu Dhabi.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">LED Screen Installation - Al Wahda Mall Abu Dhabi</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Led Screen Installation - Al Wahda Mall Abu Dhabi.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Fitness First- Dubai Silicon Oasis.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Fitness First- Dubai Silicon Oasis</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Fitness First- Dubai Silicon Oasis.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Subway.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Subway</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Subway.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/Pangaia - Mall of the Emirates - Retail.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Pangaia - Mall of the Emirates - Retail</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/Pangaia - Mall of the Emirates - Retail.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                        <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/LED INstallation - Retail 2.jpeg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">LED Installation</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/LED INstallation - Retail 2.jpeg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <!--Blog One single-->
                        <div class="blog-one__single">
                            <div class="blog-one__img">
                                <img src="assets/images/gallery/blog-1.jpg" alt="">
                            </div>
                            <div class="blog-one__content">
                                <h3 class="blog-one__title">
                                    <a href="#">Emirates Post Group</a>
                                </h3>
                                <div class="blog-one__bottom">
                                    <a class="preview_image" href="assets/images/gallery/blog-1.jpg">Preview <i class="fa fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
            
                </div>
               
            </div>
        </section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>        
<script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.js"></script>
<script>
$('.preview_image').magnificPopup({
showCloseBtn: true,
closeBtnInside: true,
type:'image'});

</script>
</script>

        <!--Blog One End-->
        <!--Blog One End-->
<?php require_once('footer.php');?>