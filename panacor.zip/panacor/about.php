<?php require_once('header.php');?>
<style>
    .anchor {
    display: block;
    position: relative;
    top: -30vh;
    visibility: hidden;
}
</style>

<title>About Us | Panacor Technologies LLC</title>
        
        <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/header-images/aboutus.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">                    
                    <h2>ABOUT US</h2>
                </div>
            </div>
        </section>  

        <section class="delivering-it">
            <div class="container">
                <div class="delivering-it__top">
                 
                </div>                
            </div>
        </section>

        <section class="trusted-company" id="profile">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img class="mob-img" src="assets/images/slider/sld4.webp" alt="" style="border-radius:20px; height:500px; margin-top: 20px;">
                                <div class="trusted-company__solution">
                                    <p class="trusted-company__solution-content">Our team includes top-notch programmers and designers whose only motivation is to stand for our clients' best interests and meet their every criterion. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6" >
                        <div class="trusted-company__right alg-up">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline" >OUR PROFILE</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">Panacor is a specialized System Integration company providing complete turnkey ICT solutions including Security, Storage solutions, Audio-Visual, Digital signage and IT solutions.</p>
                            
                            <p class="trusted-company__text-2">We have the technical expertise and capability to develop customized solutions and successfully handle the largest projects in the retail, hospitality, entertainment, healthcare, financial services, and transportation, education and government sectors across the Middle East. We provide complete turnkey solutions from Consulting, Design and Engineering to Installation and Maintenance.Panacor's partners include the biggest and the best names in the business.</p>      
                            <p class="trusted-company__text-2">Our team includes top-notch programmers and designers whose only motivation is to stand for our clients' best interests and meet their every criterion.</p>
                            
                            <p class="trusted-company__text-2">We aim to lead the industry not only in the volume and scope of work but also in the values that drive our business, and our primary motivation will always be to aim for win-win solutions that forge long- term relationships that inspire confidence, trust and credibility.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="trusted-company" id="mission">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6" >
                        <div class="trusted-company__right alg-up">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline" >MISSION & VISION</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">Panacor envisions retaining its spirit of enterprise, the ability to challenge and innovate yet remaining forever nimble and quickly responding to change as it is closely keyed in with the clients.</p>
                            
                            <p class="trusted-company__text-2">We foster a deeply-rooted sense of belonging in our people, and they feel secure to think in new directions, taking the initiative to try new approaches and solutions or taking risks that disrupt established norms. With an attitude that aims high and wide yet remains grounded, we are able to hear and understand our clients and respond to their every need.</p>      
                            <p class="trusted-company__text-2">Panacor aims to be:</p>
                            
                            <p class="trusted-company__text-2">
                                <ul class="trusted-company__text-2">
                                <li>To be the name best-known in the System Integration business for technical ability, service excellence, innovation and the willingness to take on impossible challenges</li>
                                <li>To be an organization that employs the best talent and inspires each person to give their best</li>
                                <li>To be the partner of choice for the best brands and to nurture these alliances</li>
                                <li>To be responsive to the societies we live in and serve our communities</li>
                                <li>To be the biggest player in the Middle East & Africa region in the next five years</li>
                                </ul>
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-6" >
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInRight" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/missionVision.jpg" alt="" style="border-radius:20px; height:570px; margin-top:40px">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="trusted-company" id="mission">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6" >
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/liveurvalues.jpg" alt="" style="border-radius:20px; height:530px">
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6" id="values">
                        <div class="trusted-company__right alg-up">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline">LIVE YOUR VALUES</span>                                    
                                </div>                                
                            </div>
                            <ul class="trusted-company__text-2">
                            <li class="trusted-company__text-2">Everything we do must reflect of our core values of:</li>
                            
                            <li class="trusted-company__text-2"><b>Leadership:</b> The courage to think different, take new directions and shatter perceived barriers</li>      
                            <li class="trusted-company__text-2"><b>Collaboration:</b> When inspired people act as one, the sum total is greater than its parts</li>
                            
                            <li class="trusted-company__text-2"><b>Curiosity:</b> Never accept the status-quo. Question, challenge, keep learning</li>
                            
                            <li class="trusted-company__text-2"><b>Integrity:</b> Always be authentic, real, take responsibility</li>
                            
                            <li class="trusted-company__text-2"><b>Fearlessness:</b> Nothing new will ever be done unless we take risks to find better solutions</li>
                            
                            <li class="trusted-company__text-2"><b>Responsiveness:</b> Talk to people out there, observe, listen, learn – and respond to the market quickly by changing direction if needed</li>
                            
                             <li class="trusted-company__text-2"><b>Accountability:</b> If it is to be, it is up to me</li>
                             
                              <li class="trusted-company__text-2"><b>Passion:</b> Total commitment with heart and mind can achieve anything</li>
                              
                              <li class="trusted-company__text-2"><b>Quality:</b> Whatever we do, we give it our best and aim to excel</li>
                              </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="trusted-company" id="culture">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6" >
                        <div class="trusted-company__right alg-up">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline">THE PANACOR CULTURE</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">Panacor aims to be the biggest presence in the System Integration business by 2020. This lofty an aspiration needs a solid foundation of a "Yes we can!" culture, strong ethics, an attitude of excellence and genuine enthusiasm for our work.</p>
                            
                            <p class="trusted-company__text-2">An organisations's culture is the bedrock of its internal and external interactions. At Panacor, we believe a loving, nurturing environment within will automatically create a team of people that carries the same concern outward to every client, supplier, the cities we work in and the world we live in.</p>      
                            <p class="trusted-company__text-2"><b>Every business practice we employ stems from the values we strongly believe in:</b></p>
                            
                            <p class="trusted-company__text-2">
                                <ul class="trusted-company__text-2">
                                <li>A happy employee is the best route to a satisfied client: For us to be at the top of our game, our people need to feel valued as human beings first.</li>
                                <li>Truth, Honesty and Total Transparency with every stakeholder ensures we work as one team with our clients and vendors towards fulfilling common goals.</li>
                                <li>An open, collaborative environment encourages people to challenge perceived limitations and open minds to new directions and creative, innovative solutions</li>
                                </ul>
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-6" >
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInRight" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/culture.jpg" alt="" style="border-radius:20px; height:580px">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="trusted-company" id="culture">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="trusted-company__left">
                            <div class="trusted-company__img wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <img src="assets/images/slider/values.jpg" alt="" style="border-radius:20px; height:540px">
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6" id="business">
                        <div class="trusted-company__right alg-up">
                            <div class="section-title text-left">
                                <div class="section-title__tagline-box">
                                    <span class="section-title__tagline">BEYOND BUSINESS</span>                                    
                                </div>                                
                            </div>
                            <p class="trusted-company__text-2">No individual, organization or even country can thrive in isolation. If we are to grow and prosper, we believe it is imperative that we give of ourselves, share our wealth and enrich others' lives with our knowledge and skills.</p>
                            
                            <p class="trusted-company__text-2">With Panacor's inside-out approach, a nurturing, charitable approach most certainly begins at home and our own people come first. Only when a cup is full can it overflow and give to others. As an organization, social responsibility is an integral part of our culture and every employee gives of himself / herself beyond the call of duty, beyond pure business.</p>      
                            <p class="trusted-company__text-2">Whether it is teaching others skills that will help enhance their lives or simply conducting our daily lives in ways that exhibit concern for the world around us, every one at Panacor contributes.</p>
                            
                            <p class="trusted-company__text-2">
                                <p class="trusted-company__text-2">
                                It is the intention to nurture and the sharing, caring mindset that is critical: even what may seem like a small contribution has strong ripple effects into every one of our employees' homes and to their children towards making the earth a better place.
                                </p>
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="business-from-two">
            <div class="container">
                <div class="section-title text-left hello-et">
                    <h2 class="section-title__title">Why Choose Panacor?</h2>
                </div>
                <div class="business-from-two__content-box">
                    <ul class="list-unstyled business-from-two__list">
                        <li class="business-from-two__single wow fadeInUp" data-wow-delay="100ms">
                            <div class="business-from-two__content">
                                <div class="business-from-two__icon">
                                    <img src="assets/images/icon/abt_i1.svg">
                                </div>
                                <h4 class="business-from-two__title">Best Service</h4>
                            </div>
                        </li>
                        <li class="business-from-two__single wow fadeInUp" data-wow-delay="200ms">
                            <div class="business-from-two__content">
                                <div class="business-from-two__icon">
                                    <img src="assets/images/icon/abt_i2.svg">
                                </div>
                                <h4 class="business-from-two__title">Industry Leading Systems & Tools</h4>
                            </div>
                        </li>
                        <li class="business-from-two__single wow fadeInUp" data-wow-delay="300ms">
                            <div class="business-from-two__content">
                                <div class="business-from-two__icon">
                                    <img src="assets/images/icon/abt_i3.svg">
                                </div>
                                <h4 class="business-from-two__title">Mature Services & Processes</h4>
                            </div>
                        </li>
                        <li class="business-from-two__single wow fadeInUp" data-wow-delay="400ms">
                            <div class="business-from-two__content">
                                <div class="business-from-two__icon">
                                    <img src="assets/images/icon/abt_i4.svg">
                                </div>
                                <h4 class="business-from-two__title">Best Support</h4>
                            </div>
                        </li>
                        <li class="business-from-two__single wow fadeInUp" data-wow-delay="500ms">
                            <div class="business-from-two__content">
                                <div class="business-from-two__icon">
                                    <img src="assets/images/icon/abt_i5.svg">
                                </div>
                                <h4 class="business-from-two__title">Great People & Culture</h4>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
      
        <section class="cta-one" id="team">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-2" >
                        <div class="cta-one__inner">
                            <div class="cta-one-bg" style="background-image: url(assets/images/resources/team.jpg);">
                            </div>
                            <h2 class="cta-one__title">Our Team</h2>
                            <p class="cta-one__text">Panacor Technologies LLC has an excellent team of professionals who have extensive experience in their fields. </p>
                        </div>
                    </div>
                </div>                
            </div>
        </section>
<?php require_once('footer.php');?>