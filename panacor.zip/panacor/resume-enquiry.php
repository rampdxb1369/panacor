<?php	
if(isset($_POST['send']))
{
    if(empty($_POST['name']) || empty($_POST['phone']) || empty($_POST['email']) ||empty($_FILES['resume']['name']))
    {
        header("location:career.php?missing=".urlencode('Fields are missing!Please fill them')."#profile");
        exit();
    }
    else
    {
      $name=$_POST['name'];
      $email=$_POST['email'];
      $phone=$_POST['phone'];
      if(empty($_POST['cover_letter']))
      {
         $cover_letter='N/A'; 
      }
      else
      {
          $cover_letter=$_POST['cover_letter'];
      }
      
      
	   $get_resume_name = $_FILES["resume"]["name"];
       $resume_name_file = new SplFileInfo($get_resume_name);
       $resume_name_extension  = $resume_name_file->getExtension();
       $resume_name=$name. ".$resume_name_extension";
       $resume_tmp_name = $_FILES["resume"]["tmp_name"];
       $resume_type = $_FILES['resume']['type'];
       $resume_size = $_FILES['resume']['size'];
       
       
       

       if (strtolower($resume_type) != "application/pdf" && strtolower($resume_type) != "application/doc" && strtolower($resume_type)!= "application/docx") 
            {    
               header("location:career.php?invalid= Only PDF/DOCX/DOC are allowed for resume!#profile");
                   exit();
            }
            
        $handle = fopen($resume_tmp_name, "r"); // set the file handle only for reading the file
        $file_content = fread($handle, $resume_size); // reading the file
        fclose($handle);
        
        $encoded_content = chunk_split(base64_encode($file_content));
        $boundary = md5("random");
        
        
        $headers = "MIME-Version: 1.0\r\n"; // Defining the MIME version
        $headers .= "From:".$email."\r\n"; // Sender Email
        $headers .= "Reply-To: ".$email."\r\n"; // Email address to reach back
        $headers .= "Content-Type: multipart/mixed;"; // Defining Content-Type
        $headers .= "boundary = $boundary\r\n"; //Defining the Boundary
        
        include('resume-email-template.php');
        
        $body = "--$boundary\r\n";
        $body .= "Content-Type: text/html; charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
        $body .= chunk_split(base64_encode($content));
        
        $body .= "--$boundary\r\n";
        $body .="Content-Type: $resume_type; name=".$resume_name."\r\n";
        $body .="Content-Disposition: attachment; filename=".$resume_name."\r\n";
        $body .="Content-Transfer-Encoding: base64\r\n";
        $body .="X-Attachment-Id: ".rand(1000, 99999)."\r\n\r\n";
        $body .= $encoded_content; // Attaching the encoded file with email
            
      
      $to = "info@panacor.com";
      
      $sentMailResult = mail($to, $subject, $body, $headers);
    

      if($sentMailResult)
      {
        header("location:career.php?success=".urlencode('Thank you for your inquiry! We will contact you shortly')."#profile");
            exit();  
      }
      else
      {
          header("location:career.php?invalid=".urlencode('Error Occured! Please Try Again')."#profile");
            exit();
      }
    }
    
}

?>